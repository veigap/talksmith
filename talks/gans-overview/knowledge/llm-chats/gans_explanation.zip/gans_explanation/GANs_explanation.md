# Generative Adversarial Networks (GANs)

Generative Adversarial Networks (GANs) are a class of deep learning models introduced by Ian Goodfellow in 2014. They learn to generate new data — images, audio, text — that mimics the distribution of a training set. The key idea is to pit two neural networks against each other in a competitive game.

## The two players

A GAN has two networks training simultaneously with opposing goals:

- **Generator (G)**: takes random noise as input and produces fake samples. Its goal is to fool the discriminator.
- **Discriminator (D)**: a binary classifier that receives either a real sample (from the training data) or a fake one (from G), and tries to tell them apart.

Think of it as a counterfeiter (G) trying to print fake currency and a detective (D) trying to spot the fakes. As each gets better, the other is forced to improve. At equilibrium, the counterfeiter's output is indistinguishable from real currency.

See: `gan_architecture_overview.svg`

## The minimax game

GAN training is formulated as a two-player minimax game. The discriminator maximizes its ability to classify correctly, while the generator minimizes the discriminator's accuracy on fakes:

$$\min_G \max_D \; \mathbb{E}_{x \sim p_{\text{data}}}[\log D(x)] + \mathbb{E}_{z \sim p_z}[\log(1 - D(G(z)))]$$

Breaking it down:

- D wants to push D(x) → 1 for real data and D(G(z)) → 0 for fakes.
- G wants to push D(G(z)) → 1 — i.e., make the discriminator believe its outputs are real.

In practice, G is often trained with a "non-saturating" alternative loss (maximize log D(G(z))) because the original gradient vanishes early in training when fakes are obviously fake.

## The training loop

Training alternates between updating D and updating G. Each step, D gets a little better at spotting fakes, then G adjusts to fool the improved D.

See: `gan_training_loop.svg`

## Why gradients flow the way they do

This is the part that trips most people up. During each step, **only one network's weights are updated**, but both networks are involved in the forward pass:

- **When training D**: the loss is computed from D's predictions on real and fake samples. Gradients propagate back through D only. G is treated as a fixed black box that produces fakes.
- **When training G**: the fake sample passes through G *and* D, but the gradient is computed with respect to G's weights only. D acts as a differentiable "critic" — its gradients tell G which pixels to adjust to make a fake look more real.

This is why D must be a neural network and not, say, a random forest: G needs to backpropagate *through* D to learn.

## Common failure modes

GANs are notoriously hard to train. Three failure modes dominate:

**Mode collapse** — G discovers one output that reliably fools D and produces only that, ignoring the diversity of the real distribution. You ask for handwritten digits and get the same "7" every time.

**Vanishing gradients** — D becomes too strong too quickly. It rejects all fakes with near-certainty, so log(1 − D(G(z))) saturates and G receives no useful signal.

**Non-convergence / oscillation** — the two networks chase each other in circles. G improves, D adapts, G's old strategy fails, G shifts again, and the cycle never settles into equilibrium.

## Variants

Variants were developed largely to address these issues:

- **DCGAN** — convolutional architectures for image generation
- **WGAN** — Wasserstein distance loss, more stable gradients
- **Conditional GANs (cGAN)** — G and D both receive a class label, enabling controlled generation
- **StyleGAN** — the architecture behind photorealistic face generation
- **Pix2Pix / CycleGAN** — image-to-image translation (e.g., MR → CT in medical imaging)

## GANs vs. diffusion models in medical imaging

GANs dominated medical image synthesis for years (cGANs and Pix2Pix were common for cross-modality synthesis like MR→CT), but diffusion models have largely overtaken them because they're more stable to train and produce more diverse samples — though GANs still win on inference speed since they generate in one forward pass rather than iterative denoising.
